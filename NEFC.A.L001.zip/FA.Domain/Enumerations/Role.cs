﻿namespace FA.Domain.Enumerations;

public enum Role
{
    User,
    Contributor,
    BlogOwner
}
