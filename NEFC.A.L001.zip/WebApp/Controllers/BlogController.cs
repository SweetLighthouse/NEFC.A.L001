﻿using AutoMapper;
using FA.Application.Dtos.Blogs;
using FA.Domain.Enumerations;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebApp.Commons;
using WebApp.Services;

namespace WebApp.Controllers;

public class BlogController : IndependentEntityController<BlogIndexDto, BlogDetailDto, BlogRequestDto>
{
    private readonly AuthorizerService _authorizerService;
    private string? UserId => User.FindFirst(ClaimTypes.Role)?.Value;

    public BlogController(IHttpClientFactory httpClientFactory, IMapper mapper, AuthorizerService authorizerService) 
        : base(httpClientFactory, mapper, Constants.Api.Blog)
    {
        _authorizerService = authorizerService;
    }

    public override async Task<ActionResult> Index(int page = 1)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.IndexBlog)) return View(Constants.ViewName.Forbidden);
        return await base.Index(page);
    }

    public override async Task<ActionResult> Details(Guid id)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.DetailsBlog)) return View(Constants.ViewName.Forbidden);
        return await base.Details(id);
    }

    public override ActionResult Create()
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.CreateBlog)) return View(Constants.ViewName.Forbidden);
        return base.Create();
    }

    public override async Task<ActionResult> HandleCreate([FromForm] BlogRequestDto userRequestDto)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.CreateBlog)) return View(Constants.ViewName.Forbidden);
        return await base.HandleCreate(userRequestDto);
    }

    public override async Task<ActionResult> Edit(Guid id)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.UpdateBlog)) return View(Constants.ViewName.Forbidden);
        return await base.Edit(id);
    }

    public override async Task<ActionResult> HandleEdit(Guid id, BlogRequestDto updateDto)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.UpdateBlog)) return View(Constants.ViewName.Forbidden);
        return await base.HandleEdit(id, updateDto);
    }

    public override async Task<ActionResult> Delete(Guid id)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.DeleteBlog)) return View(Constants.ViewName.Forbidden);
        return await base.Delete(id);
    }

    public override async Task<ActionResult> HandleDelete(Guid id)
    {
        if (!_authorizerService.HasPermission(UserId, ModuleAction.DeleteBlog)) return View(Constants.ViewName.Forbidden);
        return await base.HandleDelete(id);
    }
}
