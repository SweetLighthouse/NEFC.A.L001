﻿namespace FA.Application.Dtos.Accounts;

public class AccountPreviewDto
{
    public Guid Id { get; set; }
    public string Username { get; set; } = null!;
}
