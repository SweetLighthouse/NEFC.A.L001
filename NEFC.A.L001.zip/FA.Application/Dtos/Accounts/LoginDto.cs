﻿namespace FA.Application.Dtos.Accounts;

public class LoginDto
{
    public string Username { get; set; } = null!;
    public string Password { get; set; } = null!;
}
