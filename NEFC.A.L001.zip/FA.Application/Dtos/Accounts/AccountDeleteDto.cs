﻿namespace FA.Application.Dtos.Accounts;

public class AccountDeleteDto
{
    public string Password { get; set; } = null!;
}
