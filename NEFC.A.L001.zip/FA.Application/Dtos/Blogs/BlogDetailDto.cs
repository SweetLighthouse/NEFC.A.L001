﻿using FA.Domain.Entities;

namespace FA.Application.Dtos.Blogs;

public class BlogDetailDto : BaseEntity
{
    public string Name { get; set; } = null!;
}
