﻿using FA.Domain.Entities;

namespace FA.Application.Dtos.Blogs;

public class BlogIndexDto : BaseEntity
{
    public string Name { get; set; } = null!;
}
