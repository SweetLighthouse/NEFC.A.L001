﻿namespace Test;

public interface IId
{
    Guid Id { get; set; }
}
