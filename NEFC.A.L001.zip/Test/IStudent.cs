﻿namespace Test;

public interface IStudent
{
    string Name { get; set; }
}